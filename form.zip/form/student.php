
<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"/>
    <link rel="stylesheet" href="assets/css/style.css" type="text/css"/>
<style>
    select.form-control {
    -moz-appearance: none;
    -webkit-appearance: none;
    appearance: none;
    background-position: right center;
    background-repeat: no-repeat;
    background-size: 1ex;
    background-origin: content-box;
    
}
body {
background-color: paleturquoise;
}
</style>
<script src="geo/assets/js/jquery.min.js"></script>
<script src="geo/assets/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

    <div id="login-form">
        <form method="post" action="action.php"  enctype="multipart/form-data" autocomplete="off">

            <div class="col-md-12">

                <div class="form-group">
                    <h3 class="">STUDENT COLLEGE ID CARD</h3>
                </div>

                <div class="form-group">
                    <hr/>
                </div>

                <?php
                if (isset($errMSG)) {

                    ?>
                    <div class="form-group">
                        <div class="alert alert-<?php echo ($errTyp == "success") ? "success" : $errTyp; ?>">
                            <span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                        </div>
                    </div>
                    <?php
                }
                ?>

     <div class="form-group">
                <p>1. Student's ID Number</p>
             
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-number"></span></span>
                        <input type="text" name="sid" id="sid" class="form-control" placeholder="Enter Student ID" required/>
                    </div>
                    <script>
    $('#sid').keyup(function(){
    if($(this).val().length>0 && $(this).val().length<5){
        $(this).val($(this).val().charAt(0).toUpperCase()+$(this).val().substr(1));
     }
});
</script>
            <!-- Response -->
         
 <div id="uname_response" ></div>
                </div>
  
<div class="form-group">
<p>2. Select your course Session:</p>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-star"></span></span>
<select class="form-control" name="session">
  <option value="">Select...</option>
    <option value="2019">2018</option>
  <option value="2019">2019</option>
    <option value="2020">2020</option>
        <option value="2021">2021</option>
</select>
</div>
</div>
<div class="form-group">
<p>2.a. Select Course Year:</p>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-star"></span></span>
<select class="form-control" name="year">
  <option value="">Select...</option>
    <option value="1">1st Year</option>
  <option value="2">2nd Year</option>
    <option value="2">3rd Year</option>
</select>
</div>
</div>

<div class="form-group">
<p>3. Select your course:</p>
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-book"></span></span>
<select class="form-control" name="course">
<option value="">Select...</option>
<option value="B.TECH COMPUTER SCIENCE">B.TECH COMPUTER SCIENCE</option>
<option value="B.TECH COMPUTER SCIENCE (AI)">B.TECH COMPUTER SCIENCE (AI)</option>
  <option value="DIPLOMA COMPUTER SCIENCE">DIPLOMA COMPUTER SCIENCE</option>
  <option value="DIPLOMA ELECTRICAL">DIPLOMA ELECTRICAL</option>
  <option value="DIPLOMA MECHANICAL">DIPLOMA MECHANICAL</option>
  <option value="B.TECH IP COMPUTER SCIENCE">B.TECH IPU COMPUTER SCIENCE</option>
  <option value="B.TECH IP MACHENICAL ENGINEERING">B.TECH IPU MACHENICAL ENGINEERING</option>
  <option value="B.TECH IP ELECTRONICS & COMMUNICATION ENGINEERING">B.TECH IPU ELECTRONICS & COMMUNICATION ENGINEERING</option>
  <option value="B.TECH IP INFORMATION TECHINOLOGY">B.TECH IPU INFORMATION TECHINOLOGY</option>
  <option value="D.PHARMA">D.PHARMA</option>
  <option value="B.PHARMA">B.PHARMA</option>
  <option value="MBA">MBA</option>
  <option value="BBA">BBA</option>
  <option value="BCA">BCA</option>
  <option value="B.COM">B.COM</option>

    <option value="LLB">LLB</option>
  <option value="BA.LLB">BA.LLB</option>
  <option value="B.COM.LLB">B.COM.LLB</option>
</select>
</div>
</div>
                
                <div class="form-group">
                    <p>4. Upload your photo</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-picture"></span></span>
                        <input type="file" name="photo" accept="image/png, image/gif, image/jpeg, image/jpg"   class="form-control" placeholder="Upload"
                               required/>
                               
                    </div>Only allowed format (jpg/png/gif).
                </div>
                
             
                <div class="form-group">
                <p>5. Student's Name</p>
                <small>Write your Full Name</small>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        <input type="text" name="name" class="form-control" placeholder="Enter Student Name" required/>
                    </div>
                </div>
                
               <div class="form-group">
                                       <p>6. Father's Name</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        <input type="text" name="father" class="form-control" placeholder="Enter Father Name" required/>
                    </div>
                </div>



                <div class="form-group">
                                        <p>7. Email</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
                        <input type="email" name="email" class="form-control" placeholder="Enter Email" required/>
                    </div>
                </div>

                <div class="form-group">
                     <p>8.Permanent Contact Number</p>
                    <div class="input-group">
                                           
                        <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        <input type="number" name="phone" class="form-control" placeholder="Enter Phone Number" required/>
                    </div>
                </div>

                <div class="form-group">
                     <p>9.Whatsapp Number</p>
                    <div class="input-group">
                                           
                        <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        <input type="number" name="whatsapp" class="form-control" placeholder="Enter Whatsapp Number" required/>
                    </div>
                </div>
                <div class="form-group">
                                        <p>10. Write your Full Address...</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-pen"></span></span>
                        <textarea type="text" name="address" class="form-control" placeholder="Type Full Address" required/></textarea>
                    </div>
                </div>

                <div class="checkbox">
                    <label><input type="checkbox" id="TOS" value="This"><a href="#">I have cross checked the information.</a></label>
                </div>

  <div class="form-group">
                    <p>11. Terms and Conditions</p>
                    <div class="input-group">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-file"></span></span>
                        <textarea type="text" name="nothing" readonly class="form-control" placeholder="Upload"
                               required/>Filling incorrect or misleading information will be laible to be fine.
                               </textarea>
                    </div>
                </div>


                <div class="form-group">
                    <button type="submit" class="btn    btn-block btn-primary" name="signup" id="reg">Register</button>
                </div>

            
                
            </div>

        </form>
    </div>

</div>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

</body>


</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <script>
            $(document).ready(function(){

                $("#sid").keyup(function(){

                    var sid = $(this).val().trim();
            
                    if(sid != ''){
            
                       
            
                        $.ajax({
                            url: 'exist.php',
                            type: 'post',
                            data: {sid: sid},
                            success: function(response){
                
                                $('#uname_response').html(response);
                                
                                
                                 if (response == "<span style='color: green;'>Yes, You are eligible to apply.</span>") 

                               $("#submit").html("<button class='btn btn-primary ladda-button' data-style='zoom-in' type='submit'  id='SubmitButton' value='Upload' />Publish</button>");
        else if (response == "<span style='color: red;'>Already exist in database.</span>")
        {
            
                               $("#submit").html("<button class='btn btn-primary ladda-button' data-style='zoom-in' type='submit'  id='SubmitButton' value='Upload' / disabled>Publish</button>");
        }
                                
                                
                              
                            }
                        });

                    }else{
                        $("#uname_response").html("");
                         $("#submit").html("<button class='btn btn-primary ladda-button' data-style='zoom-in' type='submit'  id='SubmitButton' value='Upload' / disabled>Publish</button>");
                    }
            
                });

            });
        </script>

