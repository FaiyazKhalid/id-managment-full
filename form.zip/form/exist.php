<?php
include 'Studentid/db_connect.php';
?>
<?

if(isset($_POST['sid'])){
    $sid = mysqli_real_escape_string($db,$_POST['sid']);

    $query = "select count(*) as cntUser from `student_id_card` where sid='".$sid."'";
    
    $result = mysqli_query($db,$query);
    $response = "<span style='color: green;'>Yes, You are eligible to submit.</span>";
    if(mysqli_num_rows($result)){
        $row = mysqli_fetch_array($result);
    
        $count = $row['cntUser'];
        
        if($count > 0){
            $response = "<span style='color: red;'>Already exist in database.</span>";
        }
       
    }
    
    echo $response;
    die;
}

?>