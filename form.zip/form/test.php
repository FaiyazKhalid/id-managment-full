<select name="dropdown">
  <option value="">Default value (key thing is leaving value="")</option>
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="mercedes">Mercedes</option>
  <option value="audi">Audi</option>
</select>
<?
if($_POST['dropdown'] != '') {
  //do something
} else {
  //user leaved default value for dropdown, tell him that:
  echo "Please select valid value from dropdown list";
}
?>