			<link rel="stylesheet" href="student/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="student/css/data-table/bootstrap-editable.css">
			<div class="charts">		
			<div class="mid-content-top charts-grids">
				<div class="middle-content">
						<h4 class="title">Users</h4>
					<!-- start content_slider -->
			 <div class="data-table-area mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="sparkline13-list shadow-reset">
                                <div class="sparkline13-hd">
                                    
                                </div>
                                <div class="sparkline13-graph">
                                    <div class="datatable-dashv1-list custom-datatable-overright">
                                       <center> <a href="exportstudentlist.php">Export With Photos</a> </center>
                                        <div id="toolbar">
                                            <select class="form-control">
                                                <option value="">Export Basic</option>
                                                <option value="all">Export All</option>
                                                <option value="selected">Export Selected</option>
                                            </select>
                                        </div>
                                        <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
        <thead>
                                                <tr>
                                                    <th data-field="state" data-checkbox="true"></th>
            	<th>ID</th>
            	<th>DATE</th>
            	<th style='width:220px !important;background-color:#c7c7c7;'>PHOTO</th>
                <th>COLLEGE ID</th>
                <th>SESSION</th>
                <th>COURSE</th>
                <th>NAME</th>              
                <th>FATHER</th>
                <th>PHONE</th>           
                <th>WHATSAPP</th>
                <th>ADDRESS</th>
                <th>EMAIL</th>
                <th>Print</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
        	 <?php   
        	 
        	 $sqlmember ="SELECT * FROM student_id_card ORDER BY ID DESC";
			       $retrieve = mysqli_query($db,$sqlmember);
				                    $count=0;
                     while($found = mysqli_fetch_array($retrieve))
	                 {
                       $session=$found['session'];
                       $course=$found['course'];
                        $tdate=$found['date'];
                        date_default_timezone_set('Asia/Kolkata');
                        $s = strtotime($tdate);
$new_date = date('d-m-Y', $s);

                       $sid=$found['sid'];
                       $name=$found['name'];
                       $father=$found['father'];
                       $phone=$found['phone'];
                       $whatsapp=$found['whatsapp'];
			                $count=$count+1;  
			                $address=$found['address']; 
			                $photo=$found['photo'];
			                			                $email=$found['email'];
					    	 
			      echo"<tr>    <td>$id</td>
			                 <td>$count</td> 
			                  <td>$new_date</td> 
			              
			                          <td style='text-align:center;width:50px !important;height:50px !important;'><img src='images/$photo' style='width:50px !important;height:50px !important;'>
			                          <a href='#' class='button' id='btn-download' download='http://gnim.in/data1/form/Studentid/images/$photo'>Download</a></td>
       
			                 <td>$sid</td>  
                             <td>$session</td>
                             <td>$course</td>
                                   	
                             <td>$name</td>
                             <td>$father</td>
                             <td>$phone</td>
			                 <td>$whatsapp</td>
			                 <td>$address</td>
			                 <td>$email</td>
			                 <td>
			                   <a  href='card.php?id=$id' class='btn  btn-success' title='click to print report' ><span class='glyphicon glyphicon-print' style='color:white;'></span></a>
                              </td>
			                 <td>
			                   <a data-toggle='modal' data-id='$id' data-ie='$firstname'   data-if='$sirname' data-ig='$rank' data-ih='$dept' data-ij='$contact' data-ik='$pass' class='open-Passwords btn  btn-info' title='edit user details' href='#Passwords'><span class='glyphicon glyphicon-edit' style='color:white;'></span></a>
							 
			                 </td>				                 
			                 <td>
			                   <a data-id='$id'  class='open-Delete btn  btn-danger' title='delete user' ><span class='glyphicon glyphicon-trash' style='color:white;'></span></a>
							 
			                 </td>			 
                             </tr>"; 
					 
					 } 
		
		           	?>
            </tbody>
        
    </table>
             <button id="clear-all-button">Clear All Filters</button>
                           
				        </div>
		
				</div>

					<!--//sreen-gallery-cursual---->
			</div>
		 </div>
		</div>
	 </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<!--footer-->
	 <script>
var button = document.getElementById('btn-download');
button.addEventListener('click', function (e) {
    var dataURL = canvas.toDataURL('image/png');
    button.href = dataURL;
});
</script> 
	<script src="student/js/main.js"></script>
	 <script src="student/js/data-table/bootstrap-table.js"></script>
    <script src="student/js/data-table/tableExport.js"></script>
    <script src="student/js/data-table/data-table-active.js"></script>
    <script src="student/js/data-table/bootstrap-table-editable.js"></script>
    <script src="student/js/data-table/bootstrap-editable.js"></script>
    <script src="student/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="student/js/data-table/colResizable-1.5.source.js"></script>
    <script src="student/js/data-table/bootstrap-table-export.js"></script>