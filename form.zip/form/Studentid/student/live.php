<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>

<script>
jQuery().ready(function(){
    setInterval("getResult()",1000);
});
function getResult(){    
    jQuery.post("live-content.php",function( data ) {
        jQuery("#msgs").html(data);
   

    });
}


</script>

<style>.notification-item {
	padding:10px;
	border-bottom: #3ae2cb 1px solid;
	cursor:pointer;
}
.notification-subject {		
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.notification-comment {		
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-style:italic;
}


div.c {
  font-size: 50%;
  color:white;
}

body {
    background:black;
}

</style>

<center><h1><div id="msgs" class="c" src="notify.mp3" preload="auto"></div></h1></center>

