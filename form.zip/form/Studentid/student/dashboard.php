<?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','gnitig9i_sforms');
define('DB_PASS','gnim3395');
define('DB_NAME','gnitig9i_sforms');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>
<table>
    <tr>
        <td>Course</td>
        <td>Total</td>
    </tr>
    
<tr>
                            <?php 
$sql ="SELECT * from student_id_card";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>

                                      
                                        <td>    <h3><span class="counter"><?php echo htmlentities($totalnewapp);?></span></h3></td>
                                        
                                      
    </tr>                
                            <?php 
$sql ="SELECT * from student_id_card where course='B.TECH COMPUTER SCIENCE' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
                                        <h2 style="color: black">Total</h2>
                                            <p>B.TECH COMPUTER SCIENCE</p>
                                            <h3><span class="counter"><?php echo htmlentities($totalverapp);?></span></h3>
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='B.TECH COMPUTER SCIENCE (AI)' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
                                        <h2>Total</h2>
                                            <p>B.TECH COMPUTER SCIENCE (AI)</p>
                                            <h3><span class="counter"><?php echo htmlentities($totalrejapp);?></span></h3>
                                        </div>
                    
                            <?php 
$sql ="SELECT * from student_id_card where course='DIPLOMA COMPUTER SCIENCE'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
                    
                                        <h2>Total</h2>
                                        <div class="main-income-phara">
                                            <p>DIPLOMA COMPUTER SCIENCE</p>
                                        </div>
                    
                                            <h3><span class="counter"><?php echo htmlentities($totalnewapp);?></span></h3>
                                        </div>
                    
                            <?php 
$sql ="SELECT * from student_id_card where course='DIPLOMA ELECTRICAL' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
                                        <h2 style="color: black">Total</h2>
                                        <div class="main-income-phara order-cl">
                                            <p>DIPLOMA ELECTRICAL</p>
                                        </div>
                    
                                            <h3><span class="counter"><?php echo htmlentities($totalverapp);?></span></h3>
                    
                            <?php 
$sql ="SELECT * from student_id_card where course='DIPLOMA MECHANICAL' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
                    
                                        <h2>Total</h2>
                                        <div class="main-income-phara visitor-cl">
                                            <p>DIPLOMA MECHANICAL</p>
                                        </div>
                                            <h3><span class="counter"><?php echo htmlentities($totalrejapp);?></span></h3>
                                        </div>
                    
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP COMPUTER SCIENCE'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
                    
                                        <h2>Total</h2>
                                        <div class="main-income-phara">
                                            <p>B.TECH IP COMPUTER SCIENCE</p>
                                        </div>
                    
                                            <h3><span class="counter"><?php echo htmlentities($totalnewapp);?></span></h3>
                                        </div>
                    
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP MACHENICAL ENGINEERING' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
                    
                                        <h2 style="color: black">Total</h2>
                                        <div class="main-income-phara order-cl">
                                            <p>B.TECH IP MACHENICAL ENGINEERING</p>
                    
                                            <h3><span class="counter"><?php echo htmlentities($totalverapp);?></span></h3>
                                        </div>
                    
                            <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP MACHENICAL ENGINEERING' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
                    
                                        <h2>Total</h2>
                    
                                            <p>B.TECH IP MACHENICAL ENGINEERING</p>
                    
                                            <h3><span class="counter"><?php echo htmlentities($totalrejapp);?></span></h3>
                    
    
    
                            <?php 
$sql ="SELECT * from student_id_card where course='B.TECH IP INFORMATION TECHINOLOGY'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
                            <div class="income-dashone-total income-monthly shadow-reset nt-mg-b-30">
                               
                                <div class="income-title">
                                    <div class="main-income-head">
                                        <h2>Total</h2>
                                        <div class="main-income-phara">
                                            <p>B.TECH IP INFORMATION TECHINOLOGY</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalnewapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline1"></span>
                                        </div>
                                    </div>
                                    <div class="income-range">
                                       
                                        <a class="block text-center" href="new-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='D.PHARMA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
                            <div class="income-dashone-total orders-monthly shadow-reset nt-mg-b-30">
                                 
                                <div class="income-title">

                                    <div class="main-income-head">
                                        <h2 style="color: black">Total</h2>
                                        <div class="main-income-phara order-cl">
                                            <p>D.PHARMA</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalverapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline6"></span>
                                        </div>
                                    </div>
                                    <div class="income-range order-cl">
                                        <a class="block text-center" href="verified-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='B.PHARMA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
                            <div class="income-dashone-total visitor-monthly shadow-reset nt-mg-b-30">
                                
                                <div class="income-title">
                                    <div class="main-income-head">
                                        <h2>Total</h2>
                                        <div class="main-income-phara visitor-cl">
                                            <p>B.PHARMA</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalrejapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline2"></span>
                                        </div>
                                    </div>
                                    <div class="income-range visitor-cl">
                                        <a class="block text-center" href="verified-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
  
                         <div class="income-order-visit-user-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='MBA'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
                            <div class="income-dashone-total income-monthly shadow-reset nt-mg-b-30">
                               
                                <div class="income-title">
                                    <div class="main-income-head">
                                        <h2>Total</h2>
                                        <div class="main-income-phara">
                                            <p>MBA</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalnewapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline1"></span>
                                        </div>
                                    </div>
                                    <div class="income-range">
                                       
                                        <a class="block text-center" href="new-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='BBA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
                            <div class="income-dashone-total orders-monthly shadow-reset nt-mg-b-30">
                                 
                                <div class="income-title">

                                    <div class="main-income-head">
                                        <h2 style="color: black">Total</h2>
                                        <div class="main-income-phara order-cl">
                                            <p>BBA</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalverapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline6"></span>
                                        </div>
                                    </div>
                                    <div class="income-range order-cl">
                                        <a class="block text-center" href="verified-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='BCA' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
                            <div class="income-dashone-total visitor-monthly shadow-reset nt-mg-b-30">
                                
                                <div class="income-title">
                                    <div class="main-income-head">
                                        <h2>Total</h2>
                                        <div class="main-income-phara visitor-cl">
                                            <p>BCA</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalrejapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline2"></span>
                                        </div>
                                    </div>
                                    <div class="income-range visitor-cl">
                                        <a class="block text-center" href="verified-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
  
                                 <div class="income-order-visit-user-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='LLB'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
                            <div class="income-dashone-total income-monthly shadow-reset nt-mg-b-30">
                               
                                <div class="income-title">
                                    <div class="main-income-head">
                                        <h2>Total</h2>
                                        <div class="main-income-phara">
                                            <p>LLB</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalnewapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline1"></span>
                                        </div>
                                    </div>
                                    <div class="income-range">
                                       
                                        <a class="block text-center" href="new-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='BA.LLB' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalverapp=$query->rowCount();
?>
                            <div class="income-dashone-total orders-monthly shadow-reset nt-mg-b-30">
                                 
                                <div class="income-title">

                                    <div class="main-income-head">
                                        <h2 style="color: black">Total</h2>
                                        <div class="main-income-phara order-cl">
                                            <p>BA.LLB</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalverapp);?></span></h3>
                                        </div>
                                        <div class="price-graph">
                                            <span id="sparkline6"></span>
                                        </div>
                                    </div>
                                    <div class="income-range order-cl">
                                        <a class="block text-center" href="verified-birth-application.php"><strong style="color:white">View Detail</strong></a>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <?php 
$sql ="SELECT * from student_id_card where course='B.COM.LLB' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalrejapp=$query->rowCount();
?>
                            <div class="income-dashone-total visitor-monthly shadow-reset nt-mg-b-30">
                                
                                <div class="income-title">
                                    <div class="main-income-head">
                                        <h2>Total</h2>
                                        <div class="main-income-phara visitor-cl">
                                            <p>B.COM.LLB</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="income-dashone-pro">
                                    <div class="income-rate-total">
                                        <div class="price-adminpro-rate">
                                            <h3><span class="counter"><?php echo htmlentities($totalrejapp);?></span></h3>
        </table>

   
    <!-- Footer End-->
   
    <!-- jquery
		============================================ -->
    <script src="student/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="student/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="student/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="student/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="student/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="student/js/jquery.scrollUp.min.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="student/js/wow/wow.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="student/js/counterup/jquery.counterup.min.js"></script>
    <script src="student/js/counterup/waypoints.min.js"></script>
    <script src="student/js/counterup/counterup-active.js"></script>
    <!-- jvectormap JS
		============================================ -->
    <script src="student/js/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="student/js/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="student/js/jvectormap/jvectormap-active.js"></script>
    <!-- peity JS
		============================================ -->
    <script src="student/js/peity/jquery.peity.min.js"></script>
    <script src="student/js/peity/peity-active.js"></script>
    <!-- sparkline JS
		============================================ -->
    <script src="student/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="student/js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
		============================================ -->
    <script src="student/js/flot/Chart.min.js"></script>
    <script src="student/js/flot/dashtwo-flot-active.js"></script>
    <!-- data table JS
		============================================ -->
    <script src="student/js/data-table/bootstrap-table.js"></script>
    <script src="student/js/data-table/tableExport.js"></script>
    <script src="student/js/data-table/data-table-active.js"></script>
    <script src="student/js/data-table/bootstrap-table-editable.js"></script>
    <script src="student/js/data-table/bootstrap-editable.js"></script>
    <script src="student/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="student/js/data-table/colResizable-1.5.source.js"></script>
    <script src="student/js/data-table/bootstrap-table-export.js"></script>
    <!-- main JS
		============================================ -->
    <script src="student/js/main.js"></script>
</body>

</html>