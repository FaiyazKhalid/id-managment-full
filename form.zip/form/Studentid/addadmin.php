<?
$db = new mysqli("localhost","gnitig9i_sforms","gnim3395");
   if($db->connect_errno > 0){
         die('Unable to connect to database [' . $db->connect_error . ']');  }


if(isset($_POST['addmember'])) {
    
$mfname = mysqli_real_escape_string($db,$_POST['Firstname']);
$memail=mysqli_real_escape_string($db,$_POST['Email']);
$mphone =mysqli_real_escape_string($db,$_POST['Phone']);
$mpassword = mysqli_real_escape_string($db,$_POST['Password']);
$query = "INSERT INTO `Administrator`(`Firstname`, `Phone`, `Password`, `Email`) VALUES ('$mfname','$mphone','$mpassword','$memail')";
$db->query($query) or die('Error1, query failed');	
								 
							     $memberadd="tyy";					  
			                     $_SESSION['memberadded']=$memberadd;
                                    header("Location:dashboard.php");  //member added successfully
           
    
    
}
           