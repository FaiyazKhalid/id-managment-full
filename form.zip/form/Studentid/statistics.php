<?php 
session_start();
include("db_connect.php");

if(isset($_COOKIE['adminid'])&&$_COOKIE['adminemail']){
	
	$userid=$_COOKIE['adminid'];
$useremail=$_COOKIE['adminemail'];

$sqluser ="SELECT * FROM Administrator WHERE Password='$userid' && Email='$useremail'";

$retrieved = mysqli_query($db,$sqluser);
    while($found = mysqli_fetch_array($retrieved))
	     {
              $firstname = $found['Firstname'];
		      $sirname= $found['Sirname'];
			  $emails = $found['Email'];
			  	   $id= $found['id'];			  
   
  	     
}		 
		 
}else{
	 header('location:index.php');
      exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>

<h1>Student Statistics</h1>

<table id="customers">
  <tr><?php 
$sql ="SELECT * from student_id_card";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$totalnewapp=$query->rowCount();
?>
    <th>S.No.</th>
    <th>Course</th>
 <th>Total</th>
   
</tr>
  <tr>
    <td>1</td>
    <td>All Course</td>
    <td><span class="counter"><?php echo htmlentities($totalnewapp);?></span></td>

</tr>
  <tr>
     <?php 
$sql11 ="SELECT * from student_id_card where course='B.TECH COMPUTER SCIENCE' ";
$query11 = $dbh -> prepare($sql11);
$query11->execute();
$results11=$query11->fetchAll(PDO::FETCH_OBJ);
$brccs=$query11->rowCount();
?>
                                        
                                          
    <td>2</td>
    <td>B.TECH COMPUTER SCIENCE</td>
    <td><span class="counter"><?php echo htmlentities($brccs);?></span></td>
  </tr>
  <tr>
   <?php 
$sql22 ="SELECT * from student_id_card where course='B.TECH COMPUTER SCIENCE (AI)' ";
$query22 = $dbh -> prepare($sql22);
$query22->execute();
$results22=$query22->fetchAll(PDO::FETCH_OBJ);
$aibtc=$query22->rowCount();
?>
                                        
                                            
    <td>3</td>
    <td><p>B.TECH COMPUTER SCIENCE (AI)</p></td>
    <td><span class="counter"><?php echo htmlentities($aibtc);?></span></td>
  </tr>
  <tr>
  <?php 
$sql9 ="SELECT * from student_id_card where course='DIPLOMA COMPUTER SCIENCE'";
$query9 = $dbh -> prepare($sql9);
$query9->execute();
$results9=$query9->fetchAll(PDO::FETCH_OBJ);
$dcs=$query9->rowCount();
?>
    <td>4</td>
    <td>DIPLOMA COMPUTER SCIENCE</td>
    <td><span class="counter"><?php echo htmlentities($dcs);?></span></td>
  </tr>
  <tr>
  <?php 
$sql8 ="SELECT * from student_id_card where course='DIPLOMA ELECTRICAL' ";
$query8 = $dbh -> prepare($sql8);
$query8->execute();
$results8=$query8->fetchAll(PDO::FETCH_OBJ);
$de=$query8->rowCount();
?>
    <td>5</td>
    <td>DIPLOMA ELECTRICAL</td>
    <td><span class="counter"><?php echo htmlentities($de);?></span></td>
  </tr>
  <tr>
    <?php 
$sql7 ="SELECT * from student_id_card where course='DIPLOMA MECHANICAL' ";
$query7 = $dbh -> prepare($sql7);
$query7->execute();
$results7=$query7->fetchAll(PDO::FETCH_OBJ);
$dm=$query7->rowCount();
?>
    <td>6</td>
    <td>DIPLOMA MECHANICAL</td>
    <td><span class="counter"><?php echo htmlentities($dm);?></span></td>
  </tr>
  <tr>
   <?php 
$sql6 ="SELECT * from student_id_card where course='B.TECH IP COMPUTER SCIENCE'";
$query6 = $dbh -> prepare($sql6);
$query6->execute();
$results6=$query6->fetchAll(PDO::FETCH_OBJ);
$btipcs=$query6->rowCount();
?>
    <td>7</td>
    <td>B.TECH IP COMPUTER SCIENCE</td>
    <td><span class="counter"><?php echo htmlentities($btipcs);?></span></td>
  </tr>
  <tr>
  <?php 
$sql5 ="SELECT * from student_id_card where course='B.TECH IP MACHENICAL ENGINEERING' ";
$query5 = $dbh -> prepare($sql5);
$query5->execute();
$results5=$query5->fetchAll(PDO::FETCH_OBJ);
$btipme=$query5->rowCount();
?>
    <td>8</td>
    <td>B.TECH IP MACHENICAL ENGINEERING</td>
    <td><span class="counter"><?php echo htmlentities($btipme);?></span></td>
  </tr>
  <tr>
   <?php 
$sql4 ="SELECT * from student_id_card where course='B.TECH IP MACHENICAL ENGINEERING & COMMUNICATION ENGINEERING' ";
$query4 = $dbh -> prepare($sql4);
$query4->execute();
$results=$query4->fetchAll(PDO::FETCH_OBJ);
$btipece=$query4->rowCount();
?>
    <td>9</td>
    <td>B.TECH IP ELECTRONICS & COMMUNICATION ENGINEERING</td>
    <td><span class="counter"><?php echo htmlentities($btipece);?></span></td>
  </tr>
  <tr>
   <?php 
$sql3 ="SELECT * from student_id_card where course='B.TECH IP INFORMATION TECHINOLOGY'";
$query3 = $dbh -> prepare($sql3);
$query3->execute();
$results3=$query3->fetchAll(PDO::FETCH_OBJ);
$btip=$query3->rowCount();
?>
    <td>10</td>
    <td>B.TECH IP INFORMATION TECHINOLOGY</td>
    <td><span class="counter"><?php echo htmlentities($btip);?></span></td>
  </tr>
  <tr>
  <?php 
$sql2 ="SELECT * from student_id_card where course='D.PHARMA' ";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$dpharma=$query2->rowCount();
?>
    <td>11</td>
    <td>D.PHARMA</td>
    <td><span class="counter"><?php echo htmlentities($dpharma);?></span></td>
  </tr>
  <tr>
  <?php 
$sql1 ="SELECT * from student_id_card where course='B.PHARMA' ";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$bpharma=$query1->rowCount();
?>
    <td>12</td>
    <td>B.PHARMA</td>
    <td><span class="counter"><?php echo htmlentities($bpharma);?></span></td>
  </tr>
  <tr>
  <?php 
$mba ="SELECT * from student_id_card where course='MBA' ";
$querymba = $dbh -> prepare($mba);
$querymba->execute();
$resultsmba=$querymba->fetchAll(PDO::FETCH_OBJ);
$mba=$querymba->rowCount();
?>
    <td>13</td>
    <td>MBA</td>
    <td><span class="counter"><?php echo htmlentities($mba);?></span></td>
  </tr>
  <tr>
  <?php 
$bba ="SELECT * from student_id_card where course='BBA'";
$querybba = $dbh -> prepare($bba);
$querybba->execute();
$resultsbba=$querybba->fetchAll(PDO::FETCH_OBJ);
$bba=$querybba->rowCount();
?>
    <td>14</td>
    <td>BBA</td>
    <td><span class="counter"><?php echo htmlentities($bba);?></span></td>
  </tr>
  <tr>
  <?php 
$bca ="SELECT * from student_id_card where course='BCA' ";
$querybca = $dbh -> prepare($bca);
$querybca->execute();
$resultsbca=$querybca->fetchAll(PDO::FETCH_OBJ);
$bca=$querybca->rowCount();
?>
    <td>15</td>
    <td>BCA</td>
    <td><span class="counter"><?php echo htmlentities($bca);?></span></td>
  </tr>
  <tr>
  <?php 
$bcom ="SELECT * from student_id_card where course='B.COM' ";
$querybcom = $dbh -> prepare($bcom);
$querybcom->execute();
$resultsbcom=$querybcom->fetchAll(PDO::FETCH_OBJ);
$bcom=$querybcom->rowCount();
?>
    <td>16</td>
    <td>B.COM</td>
    <td><span class="counter"><?php echo htmlentities($bcom);?></span></td>
  </tr>
  <tr>
  <?php 
$llb ="SELECT * from student_id_card where course='LLB' ";
$queryllb = $dbh -> prepare($llb);
$queryllb->execute();
$resultsllb=$queryllb->fetchAll(PDO::FETCH_OBJ);
$llb=$queryllb->rowCount();
?>
    <td>17</td>
    <td>LLB</td>
    <td><span class="counter"><?php echo htmlentities($llb);?></span></td>
  </tr>
   <tr>
   <?php 
$ballb ="SELECT * from student_id_card where course='BA.LLB' ";
$queryballb = $dbh -> prepare($ballb);
$queryballb->execute();
$resultsballb=$queryballb->fetchAll(PDO::FETCH_OBJ);
$ballb=$queryballb->rowCount();
?>
    <td>18</td>
    <td>BA.LLB</td>
    <td><span class="counter"><?php echo htmlentities($ballb);?></span></td>
  </tr>
  <tr>
  <?php 
$aballb ="SELECT * from student_id_card where course='B.COM.LLB' ";
$aqueryballb = $dbh -> prepare($aballb);
$aqueryballb->execute();
$resultsballb=$aqueryballb->fetchAll(PDO::FETCH_OBJ);
$aballb=$aqueryballb->rowCount();
?>
    <td>19</td>
    <td>B.COM.LLB</td>
    <td><span class="counter"><?php echo htmlentities($aballb);?></span></td>
  </tr>
</table>

</body>
</html>


