	<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
                           

<?php   
				$sqln ="SELECT * FROM Inorg ";
                     $rgetb = mysqli_query($db,$sqln);
	                   $numb=mysqli_num_rows($rgetb);
                   if($numb!=0){
                            while($foundl = mysqli_fetch_array($rgetb))
	                                     {
                                              $profile= $foundl['pname'];
		                                  }
										echo"<center><img src='media/$profile'  width='70%' height='140px' alt=''></center>";	   
                               }
							else{
														     	
								
										
           ?>
            <h1>
            	<a class="navbar-brand" href="admin.php"><span class="fa fa-area-chart">
            		
            	</span>MAIN MENU<span class="dashboard_text"></span>
            	</a>
           </h1>
           <?php } ?> 

          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header">
              	 <h4>Administrator</h4>
              </li>
             <li class="treeview">
                <a href="dashboard.php">
                <i class="fa fa-tv"></i> <span>Dashboard</span>
                </a>
              </li>
              <li class="treeview">
                <a href="student-admin.php">
                <i class="fa fa-tv"></i> <span>Student Application</span>
                </a>
              </li>
              <li class="treeview">
                <a href="faculty-admin.php">
                <i class="fa fa-tv"></i> <span>Faculty Application</span>
                </a>
              </li>
                <li class="treeview">
                <a href="filter.php">
                <i class="fa fa-tv"></i> <span>Student Filter Data</span>
                </a>
              </li>
              </li>
                <li class="treeview">
                <a href="faculty-filter.php">
                <i class="fa fa-tv"></i> <span>Faculty Filter Data</span>
                </a>
              </li>

               
                            
              <li class="treeview">
                  <a data-toggle='modal' data-id='' href='#Useradd' class='open-adduser'><i class="fa fa-user"></i>Add Admin</a>
         
              </li>
              <li class="treeview">
              	  <a  href="photo.php" ><i class='fa fa-print'></i>Bulk Upload Photo</a>
               </li>
              <li class="treeview">
              	  <a  href="bulk.php" ><i class='fa fa-print'></i>Bulk registration</a>
               </li>
              <li class="treeview">
              	  <a data-toggle='modal' href="#Taxreceipted" class="Open-Taxreceipted"><i class='fa fa-print'></i>Bulk printing</a>
               </li>
                          
                </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>