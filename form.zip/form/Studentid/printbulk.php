
<?php
session_start();
include("db_connect.php");
require "vendor/autoload.php";
if(!isset($_COOKIE['adminid'])&&$_COOKIE['adminemail']){ header('location:index.php');
      exit;}
	



$fromm=$_POST['startpoint'];
$too=$_POST['endpoint'];
$startsat=$_POST['receiptrange'];


$_SESSION['from']=$fromm;
$_SESSION['to']=$too;
$_SESSION['receiptrange']=$startsat;

$from=$_SESSION['from'];
$to=$_SESSION['to'];
$startsat=$_SESSION['receiptrange'];

?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<title>card</title>
<style>
  body{
		  	background:white;
		  }
#bg {

  height: 450px;

 	float: left; 
 		
}

#id {
  width:200px;
  height:300px;
  position:absolute;
  opacity: 0.999;
font-family: sans-serif;

		  	transition: 0.4s;
		  	background-color: #FFFFFF;
		  	border-radius: 2%;
		}

#id::before {
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: url('images/back.JPG');   /*if you want to change the background image replace logo.png*/
  background-repeat:repeat-x;
  background-size: 197px 304px;
  
  z-index: -1;
  text-align:center;
 
}
 .container{
		  	font-size: 12px;
		  	font-family: sans-serif;
		    
		  }
		 .id-1{
		  	transition: 0.4s;
		  	width:250px;
		  	height:450px;
		  	background: #FFFFFF;
		  	text-align:center;
		  	font-size: 16px;
		  	font-family: sans-serif;
		  	float: left;
		  	margin:auto;		  	
		  	margin-left:270px;
		  	border-radius:2%;

		  	
		  }
</style>
	</head>

	<body>
		<script type="text/javascript">	
 		
 	window.print();
 </script>
     <style>
p.ex1 {
  text-align: right;
    margin: 20px;
    font-size: 9px;
}
img.rounded-corners {
  border-radius: 10px;
}
#boxContainer {
   
    margin: 0px auto 14px auto;
   
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;

}

tr:nth-child(even) {
    background-color: white;
}
</style> 

		  <?php  
		  $sqluse ="SELECT * FROM Inorg WHERE id=1 ";
$retrieve = mysqli_query($db,$sqluse);
    $numb=mysqli_num_rows($retrieve); 
	while($foundk = mysqli_fetch_array($retrieve))
	                                     {
                                              $profileK= $foundk['pname'];
											  $name = $foundk['name'];
		                                  }

    
      $sqlmember ="SELECT * FROM student_id_card WHERE id>=$from && id<=$to";
			       $retrieve = mysqli_query($db,$sqlmember);
				                    $count=0;
                $cnt=+1; 
		?>
		
	<?php
if (mysqli_num_rows($retrieve) > 0) {
?>	
<style>
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto auto auto;
  grid-gap: 20px;
  row-gap: 1px;
}

.grid-container > div {
 margin-right: 120px;
 height: 310px;
}

.item1 {
  grid-row: 1 / 2;
}
</style>
<div class="grid-container">
<?php
$i=0;
while($found = mysqli_fetch_array($retrieve)) {
$course=$found['course'];$name=$found['name'];$sid=$found['sid'];
                       $id=$found['id'];$session=$found['session'];$phone=$found['phone'];
			                $count=$count+1;  $address=$found['address']; $father=$found['father'];
			              $names=$firstname." ".$sirname;
						  $photo= $found['photo'];
						  
						  $serial=$id;
                          $Bar = new Picqer\Barcode\BarcodeGeneratorHTML();
                          $code = $Bar->getBarcode($serial, $Bar::TYPE_CODE_128);    
?>    		
<div class="item<? echo $cnt++; ?>">		
 <div id="bg">
            <div id="id">
<style>
    p.ex1 {
  text-align: right;
    margin: 20px;
    font-size: 8px;
}
p.para {
    font-size: 7px;
    font-weight: bold;
}

</style>                
          	
<center> 
<br><br><br><br>
<p class="ex1" style="margin-top:-10%;font-family:cambria;font-weight:bold">ID:<?php if(isset($pass)){ echo$pass;} ?></p> 
				 <div id="boxContainer">
				     
       <?
       if($photo!=""){ echo"<img src='images/$photo' class='rounded-corners' margin-top='-8px' height='92px' width='86px' alt='' style='border: none;'>";	   
									    }
								else{
									echo"<img src='admin/images/profile.jpg' height='125px' width='108px' alt='' style='border: none;'>";	   
														     	
									} 
             	 	 ?>  </div> </center>              <div class="container" align="center">
      
      	<p class="para" style="margin-top:-5%;font-family:cambria;font-size:7px;font-weight:bold">Session: 2021-23</p>
      	
      	<p style="font-weight: bold;font-family:cambria;margin-top: -3%;font-size: 15px"><?php if(isset($name)){ $namez=$name;echo$namez;} ?></p>
       <smaller> <p style="font-weight: bold;font-size:7px;font-family:cambria;margin-top:-7%">Father: <?php if(isset($father)){ echo$father;} ?><br>Course: <?php if(isset($course)){ echo$course;} ?><br>Phone: <?php if(isset($phone)){ echo$phone;} ?></p> </smaller>
       <div><?php if(isset($code)){ echo$code;}?>
      <p style="margin-top:3%;font-family:cambria;font-size: 8px" > Add: <?php if(isset($address)){ echo$address;} ?></p>
       </div>
      </div>
            </div>
          

</div
 </div>
     
    </div>
<?php
$i++;
}
?>

 <?php
}
else{
    echo "No result found";
}
?>  
	</body>
</html>
