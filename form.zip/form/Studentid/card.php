
<?php
session_start();
include("db_connect.php");
require "vendor/autoload.php";
if(!isset($_COOKIE['adminid'])&&$_COOKIE['adminemail']){ header('location:index.php');
      exit;}
	

$serial="0001";
$Bar = new Picqer\Barcode\BarcodeGeneratorHTML();
$code = $Bar->getBarcode($serial, $Bar::TYPE_CODE_128);
?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<title>card</title>
<style>
  body{
		  	background:white;
		  }
#bg {
  width: 1000px;
  height: 450px;
 
  margin:60px;
 	float: left; 
 		
}

#id {
  width:250px;
  height:450px;
  position:absolute;
  opacity: 0.88;
font-family: sans-serif;

		  	transition: 0.4s;
		  	background-color: #FFFFFF;
		  	border-radius: 2%;
		}

#id::before {
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: url('images/back.jpg');   /*if you want to change the background image replace logo.png*/
  background-repeat:repeat-x;
  background-size: 250px 450px;
  
  z-index: -1;
  text-align:center;
 
}
 .container{
		  	font-size: 12px;
		  	font-family: sans-serif;
		    
		  }
		 .id-1{
		  	transition: 0.4s;
		  	width:250px;
		  	height:450px;
		  	background: #FFFFFF;
		  	text-align:center;
		  	font-size: 16px;
		  	font-family: sans-serif;
		  	float: left;
		  	margin:auto;		  	
		  	margin-left:270px;
		  	border-radius:2%;

		  	
		  }
</style>
	</head>
<?php 
include_once("db_connect.php");

$sqluse ="SELECT * FROM Inorg WHERE id=1 ";
$retrieve = mysqli_query($db,$sqluse);
    $numb=mysqli_num_rows($retrieve); 
	while($foundk = mysqli_fetch_array($retrieve))
	                                     {
                                              $profile= $foundk['pname'];
											  $name = $foundk['name'];
		                                  }
?>
	<body>
		<script type="text/javascript">	
 		
 	window.print();
 </script>
 
      <div id="bg">
            <div id="id">
            	 <table>
            	     
        <tr> <td>
        	<?php if($numb!=0 ){
                                    if($profile!=""){echo"<img src='media/$profile'  width='70px' height='70px' alt=''>";}
									else{
										 echo"<img src='images/love.png' alt='Avatar'  width='70px' height='70px'>";
									    }	   
                               }else{
			?>
        	 <?php }?>
        <?php  
     $idx = $_GET['id'];
      $sqlmember ="SELECT * FROM Users WHERE id='$idx' ";
			       $retrieve = mysqli_query($db,$sqlmember);
				                    $count=0;
                     while($found = mysqli_fetch_array($retrieve))
	                 {
                       $title=$found['Mtitle'];$firstname=$found['Firstname'];$sirname=$found['Sirname'];$rank=$found['Rank'];
                       $id=$found['id'];$dept=$found['Department'];$contact=$found['Email'];
			                $count=$count+1;  $get_time=$found['Time']; $time=time(); $pass=$found['Staffid'];
			              $names=$firstname." ".$sirname;
						  $profile= $found['Picname'];
					 }  	 
?>
        	</td>
        	
        <td></td>
       </tr>        
    </table>
   <style>
p.ex1 {
  text-align: right;
    margin: 20px;
    font-size: 12px;
}
img.rounded-corners {
  border-radius: 10px;
}
#boxContainer {
   
    margin: -10px auto 10px auto;
   
}

</style>
<br>
<br>
<br>
<br>
<p class="ex1" style="margin-top:2%">ID:<?php if(isset($pass)){ echo$pass;} ?></p>
<br>    
    <center>
        <div id="boxContainer">
       <?
             	 	
             	 	if($profile!=""){          
										   echo"<img src='images/$profile' class='rounded-corners' margin-top='-8px' height='135px' width='108px' alt='' style='border: none;'>";	   
									    }
								else{
									echo"<img src='admin/images/profile.jpg' height='125px' width='108px' alt='' style='border: none;'>";	   
														     	
									} 
             	 	 ?>  </div> </center>              <div class="container" align="center">
      
      	<p style="margin-top:-4%">Session: 2021-23</p>
      	<p style="font-weight: bold;margin-top:-4%"><h2><?php if(isset($names)){ $namez=$names;echo$namez;} ?></h2></p>
        <p style="font-weight: bold;margin-top:-6%">Father: <?php if(isset($rank)){ echo$rank;} ?></p>
        <p style="font-weight: bold;margin-top:-6%">Course: <?php if(isset($dept)){ echo$dept;} ?></p> 
        <p style="font-weight: bold;margin-top:-6%">Phone: <?php if(isset($dept)){ echo$dept;} ?></p> 

              
      </div>
            </div>
      		 </center>
     </div>
</div>

        </div>
	</body>
</html>
