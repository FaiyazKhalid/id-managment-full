
<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration For ID Card</title>
    
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"/>
    <link rel="stylesheet" href="assets/css/style.css" type="text/css"/>
<style>
    select.form-control {
    -moz-appearance: none;
    -webkit-appearance: none;
    appearance: none;
    background-position: right center;
    background-repeat: no-repeat;
    background-size: 1ex;
    background-origin: content-box;
    
}
body {
background-color: paleturquoise;
}
</style>
<script src="geo/assets/js/jquery.min.js"></script>
<script src="geo/assets/js/bootstrap.min.js"></script>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #dddddd;
}

li {
  float: left;
}

li a {
  display: block;
  padding: 8px;
}
</style>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>

<ul>
  <li><a href="Studentid/index.php">Admin</a></li>
</ul>

<body>

<div class="container">
<center><h1>Applications</h1></center>
<br>
<br>
<center><span class="w3-tag w3-padding w3-round-large w3-red w3-center"><h2><a href="student.php">Student Application For ID Card</a></h2></span></center>
<br>
<center>Or</center>
<br>
<center><span class="w3-tag w3-padding w3-round-large w3-blue w3-center"><h2><a href="faculty.php">Employee Application For ID Card</a></h2></span></center>
<br>
<center>Or</center>
<br>
<center><span class="w3-tag w3-padding w3-round-large w3-green w3-center"><h2><a href="https://advocatespedia.com/102/form/public/forms/talent-searching-bsf">Register Your Talent 2021</a></h2></span></center>
<center>Or</center>
<br>
<center><span class="w3-tag w3-padding w3-round-large w3-yellow w3-center"><h2><a href="https://advocatespedia.com/102/form/public/forms/transportation-gab">Apply for Transportation</a></h2></span></center>
<br>
<center><span class="w3-tag w3-padding w3-round-large w3-pink w3-center"><h2><a href="https://forms.gle/RxhGAYFzrXWiPcJ8A"> For Social Media Support </a></h2></span></center>
</div>   
</body>


</html>
